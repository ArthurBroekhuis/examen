<?php 
   $path = $_SERVER['DOCUMENT_ROOT'];
   $path .= "/header.php";
   include_once($path);
?>
<section class="container section section__height" id="home">
    <h2 class="section__title">Home</h2>
</section>